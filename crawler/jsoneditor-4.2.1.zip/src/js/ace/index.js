// load brace
var ace = require('brace');

// load required ace modules
require('brace/mode/json');
require('brace/ext/searchbox');
require('./theme-jsoneditor');

module.exports = ace;
